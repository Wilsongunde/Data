package com.cytokinetics;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Cytokineticsweb {

	public static WebDriver driver;
	
	public static Select s;
	
	public static void main(String[] args) throws Exception 
	{
	
		System.setProperty("webdriver.chrome.driver","D:\\Wilson\\Data-Selenium\\chromedriver_win32\\chromedriver.exe");	
		driver = new ChromeDriver(); //launch chrome
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://cytokinetics.okta.com/app/UserHome");	//enter url
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("tvutukuri@cytokinetics.com");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("P@$$w0rd!");
		driver.findElement(By.xpath("//input[@id='okta-signin-submit']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		driver.findElement(By.xpath("//a[contains(text(),'Send code')]")).click();
		Thread.sleep(15000);
		//driver.findElement(By.xpath("")).sendKeys("");
		driver.findElement(By.xpath("//input[@value='Verify']")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//img[@alt='Graphic Link Research Hub Dev']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[2]/div/div/div/form/div/button")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		//To verify the search dashboard in left panel 
		
		driver.findElement(By.xpath("//*[@id=\"root\"]/div[2]/nav/div[2]/div/div/div[3]/div[1]/input")).sendKeys("Cyto");
		
		List<WebElement> elem = driver.findElements(By.xpath("//div[@class='ck-dashboard-search']"));
		
		System.out.println(elem.size());
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		for(WebElement b: elem)
		{
			
			String element = b.getText();
			System.out.println(element);
			
			if(element.equalsIgnoreCase("Cytodash"))
			{
			
				b.click();
				
				System.out.println("Able to search in dashboard and based on search term displaying the dashboard on main panel");
				
				break;
					
			}
			
		}
		
		
		//To verify the user is able to create Category
		
		driver.findElement(By.xpath("//*[@id='root']/div[2]/nav/div[2]/div/div/div[2]/div/div[3]/button/span[1]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@value='category']")).click();
		driver.findElement(By.xpath("//*[@class='MuiInputBase-input MuiInput-input']")).sendKeys("Testcategory");
		
		 s = new Select(driver.findElement(By.xpath("//*[@class='MuiSelect-nativeInput']")));		 
		 s.selectByIndex(5);
		 
		driver.findElement(By.xpath("//*[contains(text(),'Proceed')]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		System.out.println("Category is added and displaying in the left panel");
		
		//To verify the user is able to create Dashboard(Scenario-1)
		
		driver.findElement(By.xpath("//*[@id='root']/div[2]/nav/div[2]/div/div/div[2]/div/div[3]/button/span[1]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@class='MuiInputBase-input MuiInput-input']")).sendKeys("Cytodashboard");
		s = new Select(driver.findElement(By.xpath("//*[@class='MuiSelect-nativeInput']")));	
		s.selectByVisibleText("Testing");
		driver.findElement(By.xpath("//*[contains(text(),'Proceed')]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		System.out.println("New dashboard was added In the selected category");
		
		//To verify the user is able to create Dashboard(Scenario-2)
		
		driver.findElement(By.xpath("//*[@id='root']/div[2]/nav/div[2]/div/div/div[2]/div/div[3]/button/span[1]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@value='category']")).click();
		driver.findElement(By.xpath("//*[@class='MuiInputBase-input MuiInput-input']")).sendKeys("Testing100");
		s = new Select(driver.findElement(By.xpath("//*[@class='MuiSelect-nativeInput']")));	
		s.selectByIndex(5);
		driver.findElement(By.xpath("//span[contains(text(),'Add Dashboard')]")).click();
		driver.findElement(By.xpath("/html/body/div[184]/div[3]/div/div[2]/div/form/div/div/div[4]/div/div/input")).sendKeys("Cytotest100");
		driver.findElement(By.xpath("//*[contains(text(),'Proceed')]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		System.out.println("New category and new dashboard added and dispalying on left panel");
		
		//To verify the user is able to create Dashboard(Scenario-3)
		
		driver.findElement(By.xpath("//*[@id='root']/div[2]/nav/div[2]/div/div/div[2]/div/div[3]/button/span[1]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);	
		driver.findElement(By.xpath("//*[@class='MuiInputBase-input MuiInput-input']")).sendKeys("Testing200");		
		driver.findElement(By.xpath("//*[contains(text(),'Proceed')]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		System.out.println("A new dashboard was added in Uncategorized list");
		
		//To verify the user is able to create Dashboard(Scenario-4)
		
		driver.findElement(By.xpath("//*[@id='root']/div[2]/nav/div[2]/div/div/div[2]/div/div[3]/button/span[1]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);	
		driver.findElement(By.xpath("//*[@class='MuiInputBase-input MuiInput-input']")).sendKeys("Testing300");		
		driver.findElement(By.xpath("//*[contains(text(),'Add to favorites')]")).click();		
		driver.findElement(By.xpath("//*[contains(text(),'Proceed')]")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		System.out.println("Able to add the dashboard and displaying in favourites");
		
		//To verify the user is able to open multiple Dashboards(Scenario-1)
		
		driver.findElement(By.xpath("//*[@id='root']/div[2]/nav/div[2]/div/div/div[3]/div[10]/div/div[1]/div/div/div[1]")).click();
		
		
		
		
		
		
		
		
	}

}
