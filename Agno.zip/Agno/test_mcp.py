import asyncio
import sys
from mcp import StdioServerParameters
from mcp.client.stdio import stdio_client
from mcp.client.session import ClientSession

async def main():
    server_params = StdioServerParameters(
        command=r".vbenv\Scripts\python.exe",
        args=["-m", "windows_mcp"],
        env=None
    )
    print("Connecting to MCP server...")
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            print("Session initialized.")
            tools = await session.list_tools()
            print("Available tools:")
            for tool in tools.tools:
                print(f" - {tool.name}")

if __name__ == "__main__":
    asyncio.run(main())
