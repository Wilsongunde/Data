import sys
import os
import io
import asyncio
from agno.agent import Agent
from agno.models.groq import Groq
from agno.tools.mcp import MCPTools

# ═══════════════════════════════════════════════════
#  API KEYS
# ═══════════════════════════════════════════════════

GROQ_API_KEY = "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"

# ═══════════════════════════════════════════════════
#  SSE CONNECTION CONFIG (Port 8001)
# ═══════════════════════════════════════════════════

# Using direct SSE URL to bypass Windows pipe issues.
# Ensure the server is running on Port 8001:
# uv tool run mcp-server-browser-use --transport sse --port 8001
SSE_URL = "http://localhost:8001/sse"

TESTER_INSTRUCTIONS = """
You are a Senior QA Engineer. 
You MUST use the `run_browser_agent` tool for all web tasks.
Return a concise summary of the result.
"""

# Wrap stdout for UTF-8 on Windows
if hasattr(sys.stdout, 'buffer'):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
if hasattr(sys.stderr, 'buffer'):
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

async def main():
    query = (
        "Go to https://opensource-demo.orangehrmlive.com. "
        "Enter Username: Admin, Password: admin123. "
        "Click on the Login button."
    )
    
    print(f"\n{'='*60}")
    print("  QA Agent (Groq + Final SSE Fix)")
    print(f"{'='*60}")
    print(f"Connecting to SSE Server at: {SSE_URL}...")

    try:
        # THE FIX: Pass url directly as keyword argument
        async with MCPTools(url=SSE_URL, timeout_seconds=120) as mcp_tools:
            print(f"OK Tools loaded: {list(mcp_tools.functions.keys())}")

            agent = Agent(
                model=Groq(id="llama-3.3-70b-versatile", api_key=GROQ_API_KEY),
                instructions=TESTER_INSTRUCTIONS,
                tools=[mcp_tools],
                markdown=True,
                show_tool_calls=True,
            )

            print("Executing browser automation task...\n")
            await agent.aprint_response(query)
            
    except Exception as e:
        print(f"\nCRITICAL ERROR: {e}")
        print("\nFix: Ensure the MCP server is running on port 8001 in another terminal:")
        print("uv tool run mcp-server-browser-use --transport sse --port 8001")

if __name__ == "__main__":
    asyncio.run(main())