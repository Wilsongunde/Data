import asyncio
import os

from agno.agent import Agent
from agno.models.anthropic import Claude
from agno.tools.mcp import MCPTools

from mcp import StdioServerParameters

from agno.models.groq import Groq



# ═══════════════════════════════════════════════════
#  API KEYS
# ═══════════════════════════════════════════════════

GROQ_API_KEY = "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"

async def run_agent(message: str) -> None:
    """Run the Playwright agent with the given message."""

    server_params = StdioServerParameters(
        command="npx",
        args=[
            "@playwright/mcp@latest",
        ],
    )

    async with MCPTools(server_params=server_params) as mcp_tools:
        agent = Agent(
            model=Groq(id="llama-3.3-70b-versatile", api_key=GROQ_API_KEY),  # free model to use replace this line to make use of other model providers
            tools=[mcp_tools],
            role="Your task is to use your web browsing capabilities to find information and take actions on the web.",
            markdown=True,
        )

        await agent.aprint_response(message=message, stream=True)


if __name__ == "__main__":
    asyncio.run(
        run_agent(
            "Look for a personality test on the web and take it. Then, summarize the results of the test and provide a link to the test you took.",
        )
    )