from fastapi import FastAPI, BackgroundTasks
from pydantic import BaseModel
import anyio
import io
import sys
from agno.agent import Agent
from agno.models.groq import Groq

# Reuse credentials from agent.py or set them here
GROQ_API_KEY = "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"

app = FastAPI(title="AI Automation API")

class TaskRequest(BaseModel):
    task: str

async def run_automation_task(task_description: str):
    # Wrap stdout for logging
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    
    agent = Agent(
        model=Groq(id="llama-3.3-70b-versatile", api_key=GROQ_API_KEY),
        description="You are a task automation assistant.",
        markdown=True
    )
    
    # In a real app, you would integrate MCPTools here
    # For this example, we'll just simulate a reasoning step
    await agent.aprint_response(f"Planning and executing automation for: {task_description}")

@app.post("/run-task")
async def trigger_task(request: TaskRequest, background_tasks: BackgroundTasks):
    background_tasks.add_task(run_automation_task, request.task)
    return {"status": "Task received", "task": request.task}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
