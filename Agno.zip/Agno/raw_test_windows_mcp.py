import asyncio
import os
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def test_mcp():
    PARAMS = StdioServerParameters(
        command=r"C:\Users\wilson.gunde\AppData\Roaming\uv\tools\windows-mcp\Scripts\windows-mcp.exe",
        args=[],
        env=os.environ
    )
    
    print("Starting client (windows-mcp)...")
    try:
        async with stdio_client(PARAMS) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                print("Initialized!")
                tools = await session.list_tools()
                print(f"Tools found: {len(tools.tools)}")
                for t in tools.tools[:3]:
                    print(f" - {t.name}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(test_mcp())
