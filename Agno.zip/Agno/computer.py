"""
Agno QA Agent + Windows-MCP (Local Mode)
==========================================
SETUP:
  Full absolute path to uvx.exe (avoids PATH issues in subprocess on Windows).
  Run: Get-Command uvx | Select-Object -ExpandProperty Source  to find yours.

  Uses anyio.run() instead of asyncio.run() to avoid the TaskGroup
  'entered from different task' error in the MCP anyio client.
"""

import sys
import os
import logging
import anyio
from agno.agent import Agent
from agno.models.openrouter import OpenRouter
from agno.tools.mcp import MCPTools
from mcp import StdioServerParameters

# ===================================================
#  ENCODING: avoid UnicodeEncodeError on Windows cp1252
# ===================================================
if sys.stdout.encoding != "utf-8":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# ===================================================
#  DEBUG LOGGING: surface silent Agno/MCP errors
# ===================================================
logging.basicConfig(level=logging.INFO, format="%(levelname)s  %(name)s: %(message)s")
logging.getLogger("agno").setLevel(logging.DEBUG)

# ===================================================
#  API KEYS
# ===================================================

GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "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")

# OpenRouter - supports vision + tool calls natively
# Get a free key at: https://openrouter.ai/settings/keys
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "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")


# ===================================================
#  MCP SERVER - Local stdio mode
#  Full absolute path to uvx.exe avoids PATH resolution
#  issues in Python subprocess on Windows.
#  Found via: Get-Command uvx | Select-Object -ExpandProperty Source
# ===================================================

# Full path obtained via: Get-Command uvx | Select-Object -ExpandProperty Source
UVX_PATH = r"C:\Users\wilson.gunde\.local\bin\uvx.exe"

if sys.platform == "win32":
    server_params = StdioServerParameters(
        command=UVX_PATH,
        args=["windows-mcp"],
        env={
            **os.environ,
            "ANONYMIZED_TELEMETRY": "false",
        },
    )
else:
    server_params = StdioServerParameters(
        command="uvx",
        args=["windows-mcp"],
        env={**os.environ},
    )


# ===================================================
#  AGENT INSTRUCTIONS
# ===================================================

QA_INSTRUCTIONS = """
You are a Senior QA Engineer who can control the Windows desktop.

Available tools: Snapshot, Click, Type, Scroll, Shortcut, Wait, Move, App, Shell, File, Scrape

HOW TO BROWSE THE WEB:
1. Snapshot(use_dom=True) -- get DOM text of the screen (fast, no vision needed)
2. Open Chrome: App(name='chrome') or Click taskbar Chrome icon
3. Click address bar -> Type(text='url') -> Shortcut(keys='enter')
4. Snapshot(use_dom=True) again to read page text
5. Use Scrape(url='...') to directly scrape web pages by URL

PREFER use_dom=True for Snapshot -- it extracts clickable UI elements without
need for vision and works with ALL models, including text-only ones.

Format responses as:
## What I Did (step by step)
## What I Found (actual page content)
## Summary & Recommendation
"""


# ===================================================
#  MAIN
# ===================================================

async def run_agent(query: str):
    print(f"\n{'='*60}")
    print("  Agno + Windows-MCP  (uvx windows-mcp, stdio local mode)")
    print(f"{'='*60}")
    print(f"  Query: {query}")
    print(f"{'─'*60}\n")
    print("Connecting...")

    try:
        async with MCPTools(server_params=server_params, timeout_seconds=60) as mcp_tools:

            # Agno registers tools in .functions (dict), not .tools
            tool_names = list(mcp_tools.functions.keys())

            if not tool_names:
                print("[ERROR] No tools loaded -- check DEBUG logs above for the real error.")
                return

            print(f"[OK] Tools loaded ({len(tool_names)}): {tool_names}\n")

            agent = Agent(
                # OpenRouter supports vision + tool calls together
                # Models that work great for desktop automation:
                #   google/gemini-2.0-flash-001  -- fast, free tier, vision+tools
                #   anthropic/claude-sonnet-4-5  -- best reasoning, vision+tools
                #   openai/gpt-4o-mini           -- cheap, vision+tools
                model=OpenRouter(
                    id="nvidia/nemotron-nano-12b-v2-vl:free",
                    api_key=OPENROUTER_API_KEY or None,
                    max_tokens=4096,
                ),
                instructions=QA_INSTRUCTIONS,
                tools=[mcp_tools],
                markdown=True,

            )

            await agent.aprint_response(query, stream=True)

    except Exception as e:
        print(f"[ERROR] {type(e).__name__}: {e}")
        raise


if __name__ == "__main__":
    # Use anyio.run() with asyncio backend to avoid the TaskGroup
    # 'entered from different task' RuntimeError from the MCP anyio client
    anyio.run(
        run_agent,
        (
            "Open Chrome, go to google.com, search for "
            "'Playwright vs Selenium 2025 comparison', "
            "read the top 5 results, tell me which is better for beginners."
        ),
        backend="asyncio",
    )