import os
import requests

api_key = "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"
headers = {
    "Authorization": f"Bearer {api_key}",
    "Content-Type": "application/json",
    "HTTP-Referer": "https://localhost:3000",
    "X-Title": "Agno Agent Test"
}
data = {
    "model": "meta-llama/llama-3.3-70b-instruct:free",
    "messages": [{"role": "user", "content": "Hello, respond with 'Llama OK'."}]
}

response = requests.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=data)
print(f"Status Code: {response.status_code}")
print(f"Response: {response.json()}")
