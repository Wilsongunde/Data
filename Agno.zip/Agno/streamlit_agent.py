import os
import streamlit as st
from agno.agent import Agent
from agno.models.openrouter import OpenRouter
from agno.tools.duckduckgo import DuckDuckGoTools

# Use your OpenRouter API Key
OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "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")

# Configure the Streamlit page
st.set_page_config(page_title="AI Research Agent", page_icon="🌐")

st.title("🌐 AI Web Research Agent")
st.write("A simple web application powered by **Agno** and **Streamlit**!")

# Initialize the agent and cache it so it doesn't reload on every button click
@st.cache_resource
def get_agent():
    return Agent(
        model=OpenRouter(
            id="google/gemini-2.0-flash-lite-preview-02-05:free",
            api_key=OPENROUTER_API_KEY,
        ),
        tools=[DuckDuckGoTools()],  # Gives the agent ability to search the live web
        description="You are an expert researcher. Use DuckDuckGo to search the web and summarize your findings beautifully.",
        markdown=True,
        show_tool_calls=True # Streamlit will show what the tool is doing under the hood
    )

agent = get_agent()

# User Input
query = st.text_input("What would you like the agent to research today?", placeholder="e.g. Latest news about AI in 2025")

if st.button("Research"):
    if query:
        with st.spinner("Agent is searching the web... Please wait."):
            # Run the agent and capture the response
            response = agent.run(query)
            
            # Display the result
            st.success("Research Complete!")
            st.markdown(response.content)
    else:
        st.warning("Please enter a topic to research.")
