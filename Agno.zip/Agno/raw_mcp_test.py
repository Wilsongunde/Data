import asyncio
import os
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def test_mcp():
    PARAMS = StdioServerParameters(
        command="cmd",
        args=["/c", "uv", "tool", "run", "mcp-server-browser-use"],
        env={**os.environ, "GROQ_API_KEY": "gsk_..."}
    )
    
    print("Starting client...")
    try:
        async with stdio_client(PARAMS) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                print("Initialized!")
                tools = await session.list_tools()
                print(f"Tools: {len(tools.tools)}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    asyncio.run(test_mcp())
