import os
from agno.agent import Agent
from agno.models.openrouter import OpenRouter
from agno.tools.coding import CodingTools

OPENROUTER_API_KEY = os.environ.get("OPENROUTER_API_KEY", "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")

agent = Agent(
    model=OpenRouter(
        id="google/gemini-2.0-flash-lite-preview-02-05:free",
        api_key=OPENROUTER_API_KEY,
    ),
    tools=[CodingTools()],
    description="You are a coding assistant that can write and execute python code.",
    markdown=True,
)

# Giving it a task appropriate for CodingTools (writing & running a script)
agent.print_response("Write a python script that prints 'Hello from Agno!', save it to a file called hello.py, and then run it.", stream=True)
