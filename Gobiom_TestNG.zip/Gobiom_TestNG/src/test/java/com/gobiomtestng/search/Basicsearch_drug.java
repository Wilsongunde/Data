package com.gobiomtestng.search;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Basicsearch_drug extends Basicsearch_disease
{
	
	@Test(priority=3)
	public static void  Basicsearch_drug() throws Exception
	{
		
		
		file = new FileInputStream(filepath);
		
		WB = WB.getWorkbook(file);
		sht = WB.getSheet(0);
		
		//get row count
		int rowcount = sht.getRows();
		
		for(int i=1; i<rowcount; i++)
			
		{
			
		 String Drugvalue = sht.getCell(5,i).getContents();
		
		
				//Basic search Drug
		
				driver.findElement(By.xpath("//a[text()='Search']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[text()='Basic Search']")).click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@placeholder='Drug Name']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@placeholder='Drug Name']")).sendKeys(Drugvalue);
				driver.manage().timeouts().implicitlyWait(13, TimeUnit.SECONDS);
				
				Actions action = new Actions(driver); 
				WebElement element = driver.findElement(By.xpath("(//*[@class='searchValueChild'])[1]"));
				Thread.sleep(2000);
				
				action.moveToElement(element).build().perform();
				Thread.sleep(2000);
				element.click();
				
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@class='enableOnInput search_go']")).click();
				Thread.sleep(12000);
				  
				String e1 = driver.findElement(By.xpath("//*[text()='Drug_Name : SHIKONIN']")).getText();
				
				System.out.println("Drug searched value -> "  + e1);
				 
				
				Thread.sleep(3000);
		
		}
		
	}
	
	
	
}
