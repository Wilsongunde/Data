package com.gobiomtestng.search;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class Batchquery_ebmid extends Batchquery_entrezsymbol
{
	
	@Test(priority=6)
	public static void  Batchquery_ebmid() throws Exception
	{
	
				//Batch query EBMID search 
		
				driver.findElement(By.xpath("//a[text()='Search']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("(//a[text()='Batch Query'])[1]")).click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@Value='ebm_id']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@id='sampleData']")).click();
				Thread.sleep(3000);
				
				
				driver.findElement(By.xpath("(//*[@Value='Submit'])[2]")).click();
				Thread.sleep(6000);
				  
				String e1 = driver.findElement(By.xpath("//*[@id='Statistics']")).getText();
				
				System.out.println("EBMID searched statistics values : "  
				+ e1);
				 
				
				Thread.sleep(3000);
		
	}
	
	
	
}
