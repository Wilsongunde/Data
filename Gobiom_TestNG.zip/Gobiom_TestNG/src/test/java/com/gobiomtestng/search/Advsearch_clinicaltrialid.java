package com.gobiomtestng.search;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Advsearch_clinicaltrialid extends Basicsearch_drug
{
	
	@Test(priority=4)
	public static void  Advsearch_clinicaltrialid() throws Exception
	{
		
		
		file = new FileInputStream(filepath);
		
		WB = WB.getWorkbook(file);
		sht = WB.getSheet(0);
		
		//get row count
		int rowcount = sht.getRows();
		
		for(int i=1; i<rowcount; i++)
			
		{
			
				String Clinicaltrialidvalue = sht.getCell(6,i).getContents();
		
		
				//Advanced search Clinical trial ID
		
				driver.findElement(By.xpath("//a[text()='Search']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[text()='Advanced Search']")).click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@placeholder='Clinical Trial ID']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@placeholder='Clinical Trial ID']")).sendKeys("*");
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
				Actions action = new Actions(driver); 
				WebElement element = driver.findElement(By.xpath("(//*[@Value='2008-007246-60'])[1]"));
				Thread.sleep(2000);
				
				action.moveToElement(element).build().perform();
				Thread.sleep(2000);
				element.click();
				
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@class='enableOnInput search_go']")).click();
				Thread.sleep(8000);
				  
				String e1 = driver.findElement(By.xpath("(//*[@id='field1'])[1]")).getText();
				
				System.out.println("Adv searched value -> "  + e1);
				
				
				Thread.sleep(3000);
				
		
		}
				
	}
	
	
}
