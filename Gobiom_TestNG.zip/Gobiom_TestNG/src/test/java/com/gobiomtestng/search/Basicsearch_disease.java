package com.gobiomtestng.search;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Basicsearch_disease extends Basicsearch_biomarker
{
	
	@Test(priority=2)
	public static void  Basicsearch_disease() throws Exception
	{
		
		file = new FileInputStream(filepath);
		
		WB = WB.getWorkbook(file);
		sht = WB.getSheet(0);
		
		//get row count
		int rowcount = sht.getRows();
		
		for(int i=1; i<rowcount; i++)
			
		{
			
		 String Diseasevalue = sht.getCell(4,i).getContents();
		
		
		//Basic search Disease
		
		driver.findElement(By.xpath("//a[text()='Search']")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[text()='Basic Search']")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@placeholder='Disease Name']")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@placeholder='Disease Name']")).sendKeys(Diseasevalue);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		Actions action = new Actions(driver); 
		WebElement element = driver.findElement(By.xpath("(//*[@class='searchValueChild'])[1]"));
		Thread.sleep(2000);
		
		action.moveToElement(element).build().perform();
		Thread.sleep(2000);
		element.click();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@class='enableOnInput search_go']")).click();
		Thread.sleep(5000);
		  
		String e1 = driver.findElement(By.xpath("//*[@id='field1']")).getText();
		
		System.out.println("Disease searched value -> "  + e1);
		 
		
		Thread.sleep(3000);
		
		}
		
	}
	
	
}
