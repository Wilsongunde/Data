package com.gobiomtestng.search;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Quicksearch extends Gobiomlogin
{

	@Test(priority=1)
	public static void  Quicksearch() throws Exception
	{
		
		file = new FileInputStream(filepath);
		
		WB = WB.getWorkbook(file);
		sht = WB.getSheet(0);
		
		//get row count
		int rowcount = sht.getRows();
		
		for(int i=1; i<rowcount; i++)
			
		{
			
				String Searchvalue = sht.getCell(2,i).getContents();
		
				//Quick search
		
				driver.findElement(By.xpath("//a[text()='Search']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[text()='Quick Search']")).click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@role='combobox']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@role='combobox']")).sendKeys(Searchvalue);
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
				Actions action = new Actions(driver); 
				WebElement element = driver.findElement(By.linkText("Breast cancer"));
				Thread.sleep(2000);
				
				action.moveToElement(element).build().perform();
				Thread.sleep(2000);
				element.click();
				
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@name='BasicSearchSubmit']")).click();
				driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
				  
				String e1 = driver.findElement(By.xpath("//i[text()=' 6036 results for the search ']")).getText();
				
				System.out.println("Quick search  -> "  + e1);
				
				Thread.sleep(3000);
				
				
		}
	}
	
	
}
