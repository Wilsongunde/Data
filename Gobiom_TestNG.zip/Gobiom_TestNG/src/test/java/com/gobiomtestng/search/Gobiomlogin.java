package com.gobiomtestng.search;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;

public class Gobiomlogin 

{
	
	public static WebDriver driver;
	
	public static String filepath = "D:\\Wilson\\Data-Selenium\\Sample data\\Search.xls";
	public static FileInputStream file;
	public static Workbook WB;
	public static Sheet sht;
	
	
	@Test
	public static void  Logininitialization() throws Exception
	{
		
		System.setProperty("webdriver.chrome.driver","D:\\Wilson\\Data-Selenium\\chromedriver_win32\\chromedriver.exe");	
		driver = new ChromeDriver(); //launch chrome
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://35.154.53.99/");//enter url
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		file = new FileInputStream(filepath);
		
		WB = WB.getWorkbook(file);
		sht = WB.getSheet(0);
		
		//get row count
		int rowcount = sht.getRows();
		
		for(int i=1; i<rowcount; i++)
			
		{
			
			String Username = sht.getCell(0,i).getContents();
			String Password = sht.getCell(1,i).getContents();
		
		driver.findElement(By.xpath("//button[@class='close pull-right']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//a[text()='Customer Login']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id='username']")).sendKeys(Username);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id='password']")).sendKeys(Password);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(By.xpath("(//*[text()=' Submit'])[2]")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		WebElement e = driver.findElement(By.xpath("//*[text()='Home']"));
        
        String strng = e.getText();
        System.out.println(strng);
       
		Thread.sleep(3000);
        
		}
		
	}
	
	
}
