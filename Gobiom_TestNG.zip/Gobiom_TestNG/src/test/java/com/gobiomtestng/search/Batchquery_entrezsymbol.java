package com.gobiomtestng.search;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class Batchquery_entrezsymbol extends Advsearch_clinicaltrialid
{
	
	@Test(priority=5)
	public static void  Batchquery_entrezsymbol() throws Exception
	{
		
		file = new FileInputStream(filepath);
		
		WB = WB.getWorkbook(file);
		sht = WB.getSheet(0);
		
		//get row count
		int rowcount = sht.getRows();
		
		for(int i=1; i<rowcount; i++)
			
		{
			
			String Entrezsymbolvalue = sht.getCell(7,i).getContents();
		
	
		//Batch query Entrezsymbol search 
		
		driver.findElement(By.xpath("//a[text()='Search']")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("(//a[text()='Batch Query'])[1]")).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@Value='entrez_symbol']")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@name='textField']")).sendKeys(Entrezsymbolvalue);
		Thread.sleep(3000);
		
		
		driver.findElement(By.xpath("(//*[@Value='Submit'])[2]")).click();
		Thread.sleep(6000);
		  
		String e1 = driver.findElement(By.xpath("//*[@id='Statistics']")).getText();
		
		System.out.println("Entrezsymbol searched statistics values : "  
		+ e1);
		
		
		Thread.sleep(3000);
		
		
		}
		
	}
	
	
	
}
