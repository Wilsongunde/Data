package com.gobiomtestng.search;

import org.testng.annotations.Test;

public class Runner extends Gobiomlogout
{

	
	@Test(priority=8)
	public static void  Runner() throws Exception
	{
	
		
	}
	
	
}
