package com.gobiomtestng.reports;

import org.testng.annotations.Test;

public class Runner extends Gobiomlogout
{
	
	@Test(priority=5)
	public static void  Runner() throws Exception
	{
	
			
		
		
	}
	
	
	
	
	
}
