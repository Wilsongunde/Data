package com.gobiomtestng.reports;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Drug_report extends Disease_report
{
	
	@Test(priority=2)
	public static void  Drug_report() throws Exception
	{
		
		file = new FileInputStream(filepath);
		
		WB = WB.getWorkbook(file);
		sht = WB.getSheet(0);
		
		//get row count
		int rowcount = sht.getRows();
		
		for(int i=1; i<rowcount; i++)
			
		{
			
				String Drugreportvalue = sht.getCell(3,i).getContents();
		
				//Drug reports search
				
				driver.findElement(By.xpath("//a[text()='Reports']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("(//a[text()='Drug Report'])[1]")).click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@placeholder='Drug Name']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@placeholder='Drug Name']")).sendKeys(Drugreportvalue);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
				Actions action = new Actions(driver); 
				WebElement element = driver.findElement(By.xpath("(//*[@class='searchValueChild'])[1]"));
				Thread.sleep(2000);
				
				action.moveToElement(element).build().perform();
				Thread.sleep(2000);
				element.click();
				
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@class='enableOnInput search_go']")).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				
				String e1 = driver.findElement(By.xpath("(//*[text()='5-HYDROXYTRYPTOPHAN'])[1]")).getText();
				
				System.out.println("Drug reports searched value  -> "  + e1);
				 
		
		}
		
	}
	
	
	
}
