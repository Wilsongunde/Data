package com.gobiomtestng.reports;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Biomarker_report extends Drug_report
{
	
	@Test(priority=3)
	public static void  Biomarker_report() throws Exception
	{
	
		
		file = new FileInputStream(filepath);
		
		WB = WB.getWorkbook(file);
		sht = WB.getSheet(0);
		
		//get row count
		int rowcount = sht.getRows();
		
		for(int i=1; i<rowcount; i++)
			
		{
			
				String Biomarkerreportvalue = sht.getCell(4,i).getContents();
		
				
				//Biomarker reports search
		
				driver.findElement(By.xpath("//a[text()='Reports']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("(//a[text()='Biomarker Report'])[1]")).click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@placeholder='Biomarker Name']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@placeholder='Biomarker Name']")).sendKeys(Biomarkerreportvalue);
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
				Actions action = new Actions(driver); 
				WebElement element = driver.findElement(By.xpath("(//*[@class='searchValueChild'])[4]"));
				Thread.sleep(2000);
				
				action.moveToElement(element).build().perform();
				Thread.sleep(2000);
				element.click();
				
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@class='enableOnInput search_go']")).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				
				String e1 = driver.findElement(By.xpath("(//*[text()='EGFR (E746G) MUTATION'])[1]")).getText();
				
				System.out.println("Biomarker reports searched value  -> "  + e1);
				 
		
		}
	
	}
	
	
}
