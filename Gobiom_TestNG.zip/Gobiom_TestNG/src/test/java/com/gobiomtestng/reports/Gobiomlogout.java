package com.gobiomtestng.reports;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Gobiomlogout extends BiomarkerIndication_report
{
	
	@Test(priority=5)
	public static void  Gobiomlogout() throws Exception
	{
	
				//Logout 
		
				Actions a1 = new Actions(driver);
				WebElement we = driver.findElement(By.xpath("//*[@id='user']"));
				Thread.sleep(2000);
				a1.moveToElement(we).moveToElement(driver.findElement(By.xpath("//*[@id='logoutbutton']"))).click().build().perform();
				
				Thread.sleep(2000);
				driver.quit();
				
	}
	
	
}
