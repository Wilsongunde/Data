package com.gobiomtestng.reports;

import java.io.FileInputStream;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Disease_report extends Gobiomlogin 
{
	
	
	@Test(priority=1)
	public static void  Disease_report() throws Exception
	{
		
		file = new FileInputStream(filepath);
		
		WB = WB.getWorkbook(file);
		sht = WB.getSheet(0);
		
		//get row count
		int rowcount = sht.getRows();
		
		for(int i=1; i<rowcount; i++)
			
		{
			
				String Diseasereportvalue = sht.getCell(2,i).getContents();
		
				//Disease reports search
				
				driver.findElement(By.xpath("//a[text()='Reports']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//a[text()='Disease Report']")).click();
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@placeholder='Disease Name']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@placeholder='Disease Name']")).sendKeys(Diseasereportvalue);
				driver.manage().timeouts().implicitlyWait(35, TimeUnit.SECONDS);
				
				Actions action = new Actions(driver); 
				WebElement element = driver.findElement(By.xpath("(//*[@class='searchValueChild'])[1]"));
				Thread.sleep(2000);
				
				action.moveToElement(element).build().perform();
				Thread.sleep(2000);
				element.click();
				
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[@class='enableOnInput search_go']")).click();
				driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
				driver.findElement(By.xpath("//*[text()='Colon Cancer']")).click();
				driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
				
				String e1 = driver.findElement(By.xpath("(//*[text()='Colon Cancer'])[1]")).getText();
				
				System.out.println("Disease reports searched value  -> "  + e1);
				 
		
		}
		
		
	}
	
	
	
}
