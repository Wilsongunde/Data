from antigravity import Agent
from tools import open_website
from groq import GroqTools

web_agent = Agent(
    name="Web Automation Agent",
    goal="Open a website and login the application and navigate to admin page and extract page title",
    tools=[open_website],
    verbose=True
)