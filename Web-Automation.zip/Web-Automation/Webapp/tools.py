from playwright.sync_api import sync_playwright

def open_website(url: str):
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()

        page.goto("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
        page.fill("#username", "Admin")
        page.fill("#password", "admin123")
        page.click("#loginForm > div > div:nth-child(2) > button")

        page.goto("Admin")
        
        title = page.title()

        browser.close()

        return f"Page title is: {title}"