from agent import web_agent

task = "Open https://opensource-demo.orangehrmlive.com/web/index.php/auth/login and login with username 'Admin' and password 'admin123' and navigate to the Admin page and tell me the page title"

result = web_agent.run(task)

print(result)